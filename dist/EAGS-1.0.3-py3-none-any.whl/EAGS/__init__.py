from .EAGS_function import gaussian_smooth_adaptively
